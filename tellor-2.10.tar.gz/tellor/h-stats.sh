#!/usr/bin/env bash

get_hashrate(){
        local khs=$(grep -i 'total hashrate' ${LOG_NAME} | tail -n1 | perl -ne 'if (/total hashrate (\d+) ([KMG])H\/s/i) { print $1 * ($2 eq "G" ? 1000000 : ($2 eq "M" ? 1000 : 1)), "\n" }')
        [[ -z $khs ]] && khs=0
        echo "$khs"
}

get_miner_uptime(){
        ps -o etimes= -C TellorMiner | awk '{print $1}'
}

get_log_time_diff(){
        local last_log=`stat $LOG_NAME | grep Modify | awk {'print $2,$3'}`
        local last_log_unix=`date --date="$last_log" +%s`
        local cur_time_unix=`date +%s`
        echo `expr $cur_time_unix - $last_log_unix`
}

. /hive/miners/custom/$CUSTOM_MINER/h-manifest.conf

LOG_NAME="$CUSTOM_LOG_BASENAME.log"

local diffTime=$(get_log_time_diff)
local maxDelay=60

if [ "$diffTime" -lt "$maxDelay" ]
then
        local temp=$(jq -c ".temp" <<< $gpu_stats)
        local fan=$(jq -c ".fan" <<< $gpu_stats)

        [[ $cpu_indexes_array != '[]' ]] &&
                temp=$(jq -c "del(.$cpu_indexes_array)" <<< $temp) &&
                fan=$(jq -c "del(.$cpu_indexes_array)" <<< $fan)

        local hr=$(get_hashrate)

        stats=$(jq -nc \
                --argjson hr "$hr" \
                --arg hs_units "khs" \
                --argjson temp "$temp" \
                --argjson fan "$fan" \
                --argjson uptime "$(get_miner_uptime)" \
                --arg algo "tellor" \
                '{total_khs: $hr, hs: [], $hs_units, $temp, $fan, $uptime, ar: [0, 0], $algo}')
        khs="$hr"
fi

[[ -z $khs ]] && khs=0
[[ -z $stats ]] && stats="null"

#echo "$stats"
#echo "$khs"
