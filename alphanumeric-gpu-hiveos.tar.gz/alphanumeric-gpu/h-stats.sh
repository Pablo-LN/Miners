#!/usr/bin/env bash
# Parse the miner log -> HiveOS. MULTI-GPU: report per-GPU hashrate so HiveOS shows every card.
# Miner line: "[gpu0] 593 MH/s  [gpu1] 601 MH/s  | total 1194 MH/s | submitted=N accepted=N rejected=N ..."
log="${CUSTOM_LOG_BASENAME}.log"
line=$(tail -n 400 "$log" 2>/dev/null | grep -E '\| total [0-9.]+ MH/s' | tail -1)
total=$(echo "$line" | grep -oE 'total [0-9.]+ MH/s' | grep -oE '[0-9.]+' | head -1); [ -z "$total" ] && total=0
ac=$(echo "$line" | grep -oE 'accepted=[0-9]+' | grep -oE '[0-9]+'); [ -z "$ac" ] && ac=0
rj=$(echo "$line" | grep -oE 'rejected=[0-9]+' | grep -oE '[0-9]+'); [ -z "$rj" ] && rj=0
# per-GPU MH/s -> comma list; if none parsed yet, fall back to the total as a single card
pg=$(echo "$line" | grep -oE '\[gpu[0-9]+\] [0-9.]+ MH/s' | grep -oE ' [0-9.]+ MH/s' | grep -oE '[0-9.]+' | paste -sd, -)
[ -z "$pg" ] && pg="$total"
n=$(echo "$pg" | awk -F, '{print NF}'); [ -z "$n" ] || [ "$n" -lt 1 ] && n=1
bus=$(seq 0 $((n-1)) | paste -sd, -)
khs=$(awk "BEGIN{printf \"%.0f\", $total*1000}")
stats=$(jq -nc --argjson hs "[$pg]" --argjson bus "[$bus]" --argjson a "$ac" --argjson r "$rj" \
  '{hs:$hs,hs_units:"mhs",temp:[],fan:[],uptime:0,ar:[$a,$r],algo:"blake3",bus_numbers:$bus}' 2>/dev/null)
[ -z "$stats" ] && { stats='{"hs":['"$total"'],"hs_units":"mhs","ar":['"$ac"','"$rj"'],"algo":"blake3","bus_numbers":[0]}'; khs=$(awk "BEGIN{printf \"%.0f\", $total*1000}"); }
