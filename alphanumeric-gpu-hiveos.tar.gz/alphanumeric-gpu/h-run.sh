#!/usr/bin/env bash
cd "$(dirname "$0")"
[[ "$(pwd)" =~ /([^/]+)$ ]] && CUSTOM_NAME=${BASH_REMATCH[1]}
[[ -z $CUSTOM_LOG_BASENAME ]] && CUSTOM_LOG_BASENAME="/var/log/miner/$CUSTOM_NAME/$CUSTOM_NAME"
mkdir -p "$(dirname "$CUSTOM_LOG_BASENAME")"
# NO --gpu-index => mine on ALL discrete GPUs of the rig (one thread per card). MULTI-GPU by default.
# Pool is baked into the binary (pool-lock) -> the HiveOS "Pool URL" field is ignored on purpose.
# Wallet = flight-sheet "Wallet and worker template" (your 40-hex address). Extra = "--batch N" etc.
WAL=$(echo "$CUSTOM_TEMPLATE" | cut -d. -f1)
RIG="${WORKER_NAME:-hive}"
chmod +x ./an-gpu-miner 2>/dev/null || true
exec ./an-gpu-miner --wallet "$WAL" --rig "$RIG" $CUSTOM_USER_CONFIG 2>&1 | tee "${CUSTOM_LOG_BASENAME}.log"
