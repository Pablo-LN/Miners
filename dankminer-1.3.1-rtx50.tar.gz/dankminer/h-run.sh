#!/bin/bash
cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")"
source /hive-config/wallet.conf
source /hive-config/rig.conf
[[ -z "$CUSTOM_URL" ]] && echo "No pool URL" && exit 1
[[ -z "$CUSTOM_TEMPLATE" ]] && echo "No wallet" && exit 1

WORKER="${WORKER_NAME:-$(hostname)}"
ALGO="${CUSTOM_ALGO:-capstash}"
[[ "$ALGO" == "whirlpool-xorfold" ]] && ALGO="capstash"
[[ "$ALGO" == "warthog" || "$ALGO" == "janushash" ]] && ALGO="warthog"

rm -f stats.json
exec ./dankminer -a "$ALGO" -w "$CUSTOM_TEMPLATE" -p "$CUSTOM_URL" --worker "$WORKER"
