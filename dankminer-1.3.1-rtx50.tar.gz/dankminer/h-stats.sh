#!/usr/bin/env bash
MINER_DIR="$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")"
STATS_FILE="$MINER_DIR/stats.json"
_khs=0; _hs_json="[0]"; _temp_json="[]"; _fan_json="[]"; _bus_json="[]"; _acc=0; _rej=0; _uptime=0; _ver="1.3.1"; _algo="whirlpool-xorfold"
if [[ -f "$STATS_FILE" ]]; then
    _hs_json=$(jq -c '.hs // [0]' "$STATS_FILE" 2>/dev/null); [[ -z "$_hs_json" || "$_hs_json" == "null" ]] && _hs_json="[0]"
    _khs=$(echo "$_hs_json" | jq '[.[] | tonumber] | add // 0' 2>/dev/null); [[ -z "$_khs" || "$_khs" == "null" ]] && _khs=0
    _acc=$(jq -r '.ar[0] // 0' "$STATS_FILE" 2>/dev/null); _rej=$(jq -r '.ar[1] // 0' "$STATS_FILE" 2>/dev/null)
    _uptime=$(jq -r '.uptime // 0' "$STATS_FILE" 2>/dev/null)
    _t=$(jq -c '.temp // []' "$STATS_FILE" 2>/dev/null); _f=$(jq -c '.fan // []' "$STATS_FILE" 2>/dev/null); _b=$(jq -c '.bus_numbers // []' "$STATS_FILE" 2>/dev/null)
    [[ -n "$_t" && "$_t" != "null" && "$_t" != "[]" ]] && _temp_json="$_t"; [[ -n "$_f" && "$_f" != "null" && "$_f" != "[]" ]] && _fan_json="$_f"; [[ -n "$_b" && "$_b" != "null" && "$_b" != "[]" ]] && _bus_json="$_b"
    _v=$(jq -r '.ver // ""' "$STATS_FILE" 2>/dev/null); _a=$(jq -r '.algo // ""' "$STATS_FILE" 2>/dev/null)
    [[ -n "$_v" && "$_v" != "null" ]] && _ver="$_v"; [[ -n "$_a" && "$_a" != "null" ]] && _algo="$_a"
fi
if [[ "$_khs" == "0" ]]; then
    _api=$(curl -s --max-time 2 http://localhost:4068/api/stats 2>/dev/null)
    if [[ -n "$_api" ]]; then
        _hr=$(echo "$_api" | jq -r '.hashrate // 0' 2>/dev/null)
        if [[ -n "$_hr" && "$_hr" != "0" && "$_hr" != "null" ]]; then
            _khs=$(echo "scale=2; $_hr / 1000" | bc 2>/dev/null); [[ -z "$_khs" ]] && _khs=0
            _acc=$(echo "$_api" | jq -r '.accepted // 0' 2>/dev/null); _rej=$(echo "$_api" | jq -r '.rejected // 0' 2>/dev/null)
            _uptime=$(echo "$_api" | jq -r '.uptime // 0' 2>/dev/null)
            _hs_json="[$_khs]"
        fi
    fi
fi
if [[ "$_temp_json" == "[]" ]] && command -v nvidia-smi &>/dev/null; then
    _temps=$(nvidia-smi --query-gpu=temperature.gpu --format=csv,noheader,nounits 2>/dev/null | tr '\n' ',' | sed 's/,$//'); [[ -n "$_temps" ]] && _temp_json="[$_temps]"
    _fans=$(nvidia-smi --query-gpu=fan.speed --format=csv,noheader,nounits 2>/dev/null | tr '\n' ',' | sed 's/,$//'); [[ -n "$_fans" ]] && _fan_json="[$_fans]"
fi
khs=$_khs
stats="{\"hs\": $_hs_json, \"hs_units\": \"khs\", \"temp\": $_temp_json, \"fan\": $_fan_json, \"uptime\": $_uptime, \"ver\": \"$_ver\", \"algo\": \"$_algo\", \"ar\": [$_acc, $_rej], \"bus_numbers\": $_bus_json}"
