#!/bin/bash
pid=$(pgrep -f "dankminer.*-a " 2>/dev/null)
if [[ -n "$pid" ]]; then
    kill $pid 2>/dev/null
    sleep 2
    kill -9 $pid 2>/dev/null
fi
