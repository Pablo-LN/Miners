#!/usr/bin/env bash

. h-manifest.conf

[[ `ps aux | grep "./mochimo-binary" | grep -v grep | wc -l` != 0 ]] &&
  echo -e "Mochimo miner is already running." &&
  exit 1

conf=`cat $MINER_CONFIG_FILENAME`

echo $conf

if [[ $conf=~';' ]]; then
    conf=`echo $conf | tr -d '\'`
fi

echo "[DEBUG] WALLET: $CUSTOM_TEMPLATE"
echo "[DEBUG] WORKER: $WORKER_NAME"
echo "[DEBUG] CONFIG: $CUSTOM_USER_CONFIG"

eval "unbuffer ./lpmochimo ${conf//;/'\;'}"
